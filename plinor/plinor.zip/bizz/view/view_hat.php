<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="<?php echo URL_BASE;?>/css/landing.css">
    <link rel="stylesheet" type="text/css" href="<?php echo URL_BASE;?>/css/enter.css">
    <link rel="stylesheet" type="text/css" href="<?php echo URL_BASE;?>/css/menu.css">
    <link rel="stylesheet" type="text/css" href="<?php echo URL_BASE;?>/css/article.css">
    <link rel="stylesheet" type="text/css" href="<?php echo URL_BASE;?>/css/art_man.css">
    <link rel="stylesheet" type="text/css" href="<?php echo URL_BASE;?>/css/list.css">
    <link rel="shortcut icon"  href="<?php echo URL_BASE;?>/pic/web_logo/logo.ico" type="image/x-icon">
    <title>Плинор-техника</title>
</head>
<body>
<script src="<?php echo URL_BASE;?>/js/jq.js"></script>
<script src="<?php echo URL_BASE;?>/js/tag.js"></script>
<script src="<?php echo URL_BASE;?>/js/file_name.js"></script>