<?php
include "bizz/view/view_hat.php";
include "bizz/view/view_menu.php";
include "bizz/view/$content_view";
//include "bizz/view/view_footer.php";